<?php

namespace App\GraphQL\Resolvers;

use Illuminate\Support\Facades\Cache;
use App\Models\Matches;

class MatchResolver
{
    public function byFilter($root, array $args)
    {
        $cacheKey = "matches_{$args['league_id']}_{$args['round_id']}_{$args['season_id']}";

        // Check cache status
        if (Cache::has($cacheKey)) {
            $GLOBALS['cache_status'] = 'HIT';
        } else {
            $GLOBALS['cache_status'] = 'MISS';
        }
        return Cache::remember($cacheKey, 300, function () use ($args) {
            return Matches::where('league_id', $args['league_id'])
                ->where('round_id', $args['round_id'])
                ->where('season_id', $args['season_id'])
                ->orderBy('match_date')
                ->get();
        });
    }
}