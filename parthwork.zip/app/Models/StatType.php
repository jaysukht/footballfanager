<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StatType extends Model
{
    protected $table = 'stat_type';
    protected $guarded = [];
}
