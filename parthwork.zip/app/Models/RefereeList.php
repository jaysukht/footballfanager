<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RefereeList extends Model
{
    protected $table = 'referee_list';
    protected $guarded = [];
}
