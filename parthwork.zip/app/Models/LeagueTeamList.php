<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LeagueTeamList extends Model
{
    //
    protected $table = 'league_team_list';
    protected $guarded = [];
}
