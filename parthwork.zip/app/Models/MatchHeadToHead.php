<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MatchHeadToHead extends Model
{
    //
    protected $table = 'match_head_to_head';
    protected $guarded = [];
}
