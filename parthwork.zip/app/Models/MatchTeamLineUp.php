<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MatchTeamLineUp extends Model
{
    //

    protected $table = 'match_team_line_up';
    protected $guarded = [];
}
