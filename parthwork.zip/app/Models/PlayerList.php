<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PlayerList extends Model
{
    //
    protected $table = 'players_list';
    protected $guarded = [];
}
