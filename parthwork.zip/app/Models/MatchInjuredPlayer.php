<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MatchInjuredPlayer extends Model
{
    //

    protected $table = 'match_team_injured_player';
    protected $guarded = [];
}
