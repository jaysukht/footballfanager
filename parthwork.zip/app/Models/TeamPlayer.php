<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TeamPlayer extends Model
{
    //
    protected $table = 'team_player';
    protected $guarded = [];
}
