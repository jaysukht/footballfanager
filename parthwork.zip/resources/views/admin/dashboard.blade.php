@extends('layouts.include.admin')
@section('content')
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
    <div class="dash-cls">
        <div class="dashboard services-cls">
            <div class="dashboard-container">
                <div class="welcome-box">
                    <h2>Welcome admin</h2>
                </div>
            </div>
        </div>
    </div>
    <!-- End Agent dashboard-->
    <script></script>
    <!-- hpurs repoe -->
@endsection
