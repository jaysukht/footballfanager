<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\AllPlayersController;
use App\Http\Controllers\AllRefereeController;
use App\Http\Controllers\AllTeamPlayerController;
use App\Http\Controllers\CountryController;
use App\Http\Controllers\LanguageController;
use App\Http\Controllers\LeagueController;
use App\Http\Controllers\LeagueListController;
use App\Http\Controllers\MatchController;
use App\Http\Controllers\RoundController;
use App\Http\Controllers\SeasonController;
use App\Http\Controllers\StatTypeController;
use App\Http\Controllers\TeamController;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    if (Auth::check()) {
        return redirect('/admin/dashboard');
    }
    return redirect()->route('login');
});
Route::get('/logout', function () {
    Auth::logout();
    return redirect('/login');
});
Auth::routes();
Route::middleware(['auth'])->group(function () {
    Route::prefix('admin')->name('admin.')->group(function () {
        Route::get('/', function () {
            return redirect()->route('admin.dashboard');
        });
        Route::get('dashboard', [AdminController::class, 'index'])->name('dashboard');
        Route::get('/countries', [CountryController::class, 'index'])->name('countries.index');
        Route::get('/countries/data', [CountryController::class, 'data'])->name('countries.data');
        Route::get('/countries/create', [CountryController::class, 'create'])->name('countries.create');
        Route::post('/countries/store', [CountryController::class, 'store'])->name('countries.store');
        Route::get('/countries/edit/{id}/{language_id}/{default_language_post_id}', [CountryController::class, 'edit'])->name('countries.edit');
        Route::post('/countries/update/{id}/{language_id}/{default_language_post_id}', [CountryController::class, 'update'])->name('countries.update');
        Route::get('/sub-country/add/{id}/{language_id}', [CountryController::class, 'addSubCountry'])->name('sub-country.add');
        Route::post('/sub-country/store/{id}/{language_id}', [CountryController::class, 'storeSubCountry'])->name('sub-country.store');
        Route::post('/countries/delete', [CountryController::class, 'delete'])->name('countries.delete');

        // Language Routes
        Route::get('/languages', [LanguageController::class, 'index'])->name('languages.index');
        Route::get('/languages/data', [LanguageController::class, 'data'])->name('languages.data');
        Route::get('/languages/create', [LanguageController::class, 'create'])->name('languages.create');
        Route::post('/languages/store', [LanguageController::class, 'store'])->name('languages.store');
        Route::get('/languages/edit/{id}', [LanguageController::class, 'edit'])->name('languages.edit');
        Route::post('/languages/update/{id}', [LanguageController::class, 'update'])->name('languages.update');
        Route::post('/languages/delete', [LanguageController::class, 'delete'])->name('languages.delete');

        // League Routes
        Route::get('/leagues', [LeagueController::class, 'index'])->name('leagues.index');
        Route::get('/leagues/data', [LeagueController::class, 'data'])->name('leagues.data');
        Route::get('/leagues/create', [LeagueController::class, 'create'])->name('leagues.create');
        Route::post('/leagues/store', [LeagueController::class, 'store'])->name('leagues.store');
        Route::get('/leagues/edit/{id}/{language_id}/{default_language_post_id}', [LeagueController::class, 'edit'])->name('leagues.edit');
        Route::post('/leagues/update/{id}/{language_id}/{default_language_post_id}', [LeagueController::class, 'update'])->name('leagues.update');
        Route::get('/sub-league/add/{id}/{language_id}', [LeagueController::class, 'addSubLeague'])->name('sub-league.add');
        Route::post('/sub-league/store/{id}/{language_id}', [LeagueController::class, 'storeSubLeague'])->name('sub-league.store');
        Route::post('/leagues/delete', [LeagueController::class, 'delete'])->name('leagues.delete');

        //Season
        Route::get('/seasons', [SeasonController::class, 'index'])->name('seasons.index');
        Route::get('/seasons/data', [SeasonController::class, 'data'])->name('seasons.data');
        Route::get('/seasons/create', [SeasonController::class, 'create'])->name('seasons.create');
        Route::post('/seasons/store', [SeasonController::class, 'store'])->name('seasons.store');
        Route::get('/seasons/edit/{id}', [SeasonController::class, 'edit'])->name('seasons.edit');
        Route::post('/seasons/update/{id}', [SeasonController::class, 'update'])->name('seasons.update');
        Route::post('/seasons/delete', [SeasonController::class, 'delete'])->name('seasons.delete');

        //Team
        Route::get('/teams', [TeamController::class, 'index'])->name('teams.index');
        Route::get('/teams/data', [TeamController::class, 'data'])->name('teams.data');
        Route::get('/teams/create', [TeamController::class, 'create'])->name('teams.create');
        Route::post('/teams/store', [TeamController::class, 'store'])->name('teams.store');
        Route::get('/teams/edit/{id}/{language_id}/{default_language_post_id}', [TeamController::class, 'edit'])->name('teams.edit');
        Route::post('/teams/update/{id}/{language_id}/{default_language_post_id}', [TeamController::class, 'update'])->name('teams.update');
        Route::get('/sub-team/add/{id}/{language_id}', [TeamController::class, 'addSubTeam'])->name('sub-team.add');
        Route::post('/sub-team/store/{id}/{language_id}', [TeamController::class, 'storeSubTeam'])->name('sub-team.store');
        Route::post('/teams/delete', [TeamController::class, 'delete'])->name('teams.delete');

        //Round
        Route::get('/rounds', [RoundController::class, 'index'])->name('rounds.index');
        Route::get('/rounds/data', [RoundController::class, 'data'])->name('rounds.data');
        Route::get('/rounds/create', [RoundController::class, 'create'])->name('rounds.create');
        Route::post('/rounds/store', [RoundController::class, 'store'])->name('rounds.store');
        Route::get('/rounds/edit/{id}/{language_id}/{default_language_post_id}', [RoundController::class, 'edit'])->name('rounds.edit');
        Route::post('/rounds/update/{id}/{language_id}/{default_language_post_id}', [RoundController::class, 'update'])->name('rounds.update');
        Route::get('/sub-round/add/{id}/{language_id}', [RoundController::class, 'addSubRound'])->name('sub-round.add');
        Route::post('/sub-round/store/{id}/{language_id}', [RoundController::class, 'storeSubRound'])->name('sub-round.store');
        Route::post('/rounds/delete', [RoundController::class, 'delete'])->name('rounds.delete');

        //Match
        Route::get('/matches', [MatchController::class, 'index'])->name('matches.index');
        Route::get('/matches/data', [MatchController::class, 'data'])->name('matches.data');
        Route::get('/matches/create', [MatchController::class, 'create'])->name('matches.create');
        Route::post('/matches/store', [MatchController::class, 'store'])->name('matches.store');
        Route::get('/matches/edit/{id}/{language_id}/{default_language_post_id}', [MatchController::class, 'edit'])->name('matches.edit');
        Route::post('/matches/update/{id}/{language_id}/{default_language_post_id}', [MatchController::class, 'update'])->name('matches.update');
        Route::get('/sub-match/add/{id}/{language_id}', [MatchController::class, 'addSubMatch'])->name('sub-match.add');
        Route::post('/sub-match/store/{id}/{language_id}', [MatchController::class, 'storeSubMatch'])->name('sub-match.store');
        Route::post('/matches/delete', [MatchController::class, 'delete'])->name('matches.delete');

        //League List
        Route::get('/league-list', [LeagueListController::class, 'index'])->name('league-list.index');
        Route::get('/league-list/data', [LeagueListController::class, 'data'])->name('league-list.data');
        Route::get('/league-list/create', [LeagueListController::class, 'create'])->name('league-list.create');
        Route::post('/league-list/store', [LeagueListController::class, 'store'])->name('league-list.store');
        Route::get('/league-list/edit/{id}/{language_id}/{default_language_post_id}', [LeagueListController::class, 'edit'])->name('league-list.edit');
        Route::post('/league-list/update/{id}/{language_id}/{default_language_post_id}', [LeagueListController::class, 'update'])->name('league-list.update');
        Route::get('/sub-league-list/add/{id}/{language_id}', [LeagueListController::class, 'addSubLeagueList'])->name('sub-league-list.add');
        Route::post('/sub-league-list/store/{id}/{language_id}', [LeagueListController::class, 'storeSubLeagueList'])->name('sub-league-list.store');
        Route::post('/league-list/delete', [LeagueListController::class, 'delete'])->name('league-list.delete');

        //All Players
        Route::get('/all-players', [AllPlayersController::class, 'index'])->name('all-players.index');
        Route::get('/all-players/data', [AllPlayersController::class, 'data'])->name('all-players.data');
        Route::get('/all-players/create', [AllPlayersController::class, 'create'])->name('all-players.create');
        Route::post('/all-players/store', [AllPlayersController::class, 'store'])->name('all-players.store');
        Route::get('/all-players/edit/{id}/{language_id}/{default_language_post_id}', [AllPlayersController::class, 'edit'])->name('all-players.edit');
        Route::post('/all-players/update/{id}/{language_id}/{default_language_post_id}', [AllPlayersController::class, 'update'])->name('all-players.update');
        Route::get('/sub-all-players/add/{id}/{language_id}', [AllPlayersController::class, 'addSubAllPlayers'])->name('sub-all-players.add');
        Route::post('/sub-all-players/store/{id}/{language_id}', [AllPlayersController::class, 'storeSubAllPlayers'])->name('sub-all-players.store');
        Route::post('/all-players/delete', [AllPlayersController::class, 'delete'])->name('all-players.delete');

        //Stat Type
        Route::get('/stat-type', [StatTypeController::class, 'index'])->name('stat-type.index');
        Route::get('/stat-type/data', [StatTypeController::class, 'data'])->name('stat-type.data');
        Route::get('/stat-type/create', [StatTypeController::class, 'create'])->name('stat-type.create');
        Route::post('/stat-type/store', [StatTypeController::class, 'store'])->name('stat-type.store');
        Route::get('/stat-type/edit/{id}/{language_id}/{default_language_post_id}', [StatTypeController::class, 'edit'])->name('stat-type.edit');
        Route::post('/stat-type/update/{id}/{language_id}/{default_language_post_id}', [StatTypeController::class, 'update'])->name('stat-type.update');
        Route::get('/sub-stat-type/add/{id}/{language_id}', [StatTypeController::class, 'addSubStatType'])->name('sub-stat-type.add');
        Route::post('/sub-stat-type/store/{id}/{language_id}', [StatTypeController::class, 'storeSubStatType'])->name('sub-stat-type.store');
        Route::post('/stat-type/delete', [StatTypeController::class, 'delete'])->name('stat-type.delete');

        //All Team Player
        Route::get('/all-team-player', [AllTeamPlayerController::class, 'index'])->name('all-team-player.index');
        Route::get('/all-team-player/data', [AllTeamPlayerController::class, 'data'])->name('all-team-player.data');
        Route::get('/all-team-player/create', [AllTeamPlayerController::class, 'create'])->name('all-team-player.create');
        Route::post('/all-team-player/store', [AllTeamPlayerController::class, 'store'])->name('all-team-player.store');
        Route::get('/all-team-player/edit/{id}/{language_id}/{default_language_post_id}', [AllTeamPlayerController::class, 'edit'])->name('all-team-player.edit');
        Route::post('/all-team-player/update/{id}/{language_id}/{default_language_post_id}', [AllTeamPlayerController::class, 'update'])->name('all-team-player.update');
        Route::get('/sub-all-team-player/add/{id}/{language_id}', [AllTeamPlayerController::class, 'addSubAllTeamPlayer'])->name('sub-all-team-player.add');
        Route::post('/sub-all-team-player/store/{id}/{language_id}', [AllTeamPlayerController::class, 'storeSubAllTeamPlayer'])->name('sub-all-team-player.store');
        Route::post('/all-team-player/delete', [AllTeamPlayerController::class, 'delete'])->name('all-team-player.delete');
        

        // All Referee
        Route::get('/all-referee', [AllRefereeController::class, 'index'])->name('all-referee.index');
        Route::get('/all-referee/data', [AllRefereeController::class, 'data'])->name('all-referee.data');
        Route::get('/all-referee/create', [AllRefereeController::class, 'create'])->name('all-referee.create');
        Route::post('/all-referee/store', [AllRefereeController::class, 'store'])->name('all-referee.store');
        Route::get('/all-referee/edit/{id}/{language_id}/{default_language_post_id}', [AllRefereeController::class, 'edit'])->name('all-referee.edit');
        Route::post('/all-referee/update/{id}/{language_id}/{default_language_post_id}', [AllRefereeController::class, 'update'])->name('all-referee.update');
        Route::get('/sub-all-referee/add/{id}/{language_id}', [AllRefereeController::class, 'addSubAllReferee'])->name('sub-all-referee.add');
        Route::post('/sub-all-referee/store/{id}/{language_id}', [AllRefereeController::class, 'storeSubAllReferee'])->name('sub-all-referee.store');
        Route::post('/all-referee/delete', [AllRefereeController::class, 'delete'])->name('all-referee.delete');

    });
});
Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');


Route::get('/clear', function () {
    Artisan::call('cache:clear');
    Artisan::call('config:cache');
    Artisan::call('config:clear');
    Artisan::call('view:clear');
    return "Cleared!";
});
